/**
 * Bruce Remote — app.js
 *
 * Talks DIRECTLY to the Cardputer's Bruce WebUI over native HTTP via
 * Capacitor's built-in CapacitorHttp bridge (window.Capacitor.Plugins.CapacitorHttp).
 * This is a native networking call, not a page-context fetch() — so it is not
 * subject to browser CORS or mixed-content blocking, which is what a normal
 * mobile browser would hit against a plain-HTTP LAN device.
 *
 * Every endpoint/param here matches server.js exactly, which itself was
 * verified line-by-line against the firmware source
 * (src/core/wifi/webInterface.cpp, BruceDevices/firmware).
 */

const Http = (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorHttp) || null;

let state = {
  baseUrl: null,
  cookie: null,
  fs: "LittleFS",
  folder: "/"
};

function $(id) { return document.getElementById(id); }

async function httpRequest(opts) {
  if (!Http) throw new Error("Native HTTP bridge unavailable (are you running outside the Android app?)");
  return Http.request(opts);
}

function authHeaders(extra = {}) {
  const h = Object.assign({}, extra);
  if (state.cookie) h["Cookie"] = state.cookie;
  return h;
}

function extractCookie(resp) {
  const raw = resp.headers && (resp.headers["set-cookie"] || resp.headers["Set-Cookie"]);
  if (!raw) return null;
  const first = Array.isArray(raw) ? raw[0] : raw;
  const match = first.match(/BRUCESESSION=[^;]+/);
  return match ? match[0] : null;
}

// ---------------------------------------------------------------- connect
async function connect(host, port, username, password) {
  const baseUrl = `http://${host}${port ? ":" + port : ""}`;
  const resp = await httpRequest({
    url: baseUrl + "/login",
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    data: `username=${encodeURIComponent(username || "admin")}&password=${encodeURIComponent(password || "bruce")}`,
    disableRedirects: true
  });
  const cookie = extractCookie(resp);
  if (!cookie) throw new Error("Login failed — check address, username and password.");
  state.baseUrl = baseUrl;
  state.cookie = cookie;
}

// ------------------------------------------------------------------- /cm
async function sendCommand(cmnd) {
  const resp = await httpRequest({
    url: state.baseUrl + "/cm",
    method: "POST",
    headers: authHeaders({ "Content-Type": "application/x-www-form-urlencoded" }),
    data: "cmnd=" + encodeURIComponent(cmnd)
  });
  return typeof resp.data === "string" ? resp.data : JSON.stringify(resp.data);
}

async function sendNav(action, ms) {
  return sendCommand("nav " + action + (ms ? " " + ms : ""));
}

// -------------------------------------------------------------- systeminfo
async function getSystemInfo() {
  const resp = await httpRequest({ url: state.baseUrl + "/systeminfo", method: "GET", headers: authHeaders() });
  return typeof resp.data === "string" ? JSON.parse(resp.data) : resp.data;
}

// -------------------------------------------------------------- listfiles
async function listFiles(fs, folder) {
  const resp = await httpRequest({
    url: state.baseUrl + "/listfiles",
    method: "GET",
    headers: authHeaders(),
    params: { fs, folder }
  });
  const text = typeof resp.data === "string" ? resp.data : "";
  const lines = text.split("\n").filter(Boolean);
  const entries = [];
  for (const line of lines) {
    const parts = line.split(":");
    if (parts[0] === "Fo") entries.push({ type: "folder", name: parts[1] });
    else if (parts[0] === "Fi") entries.push({ type: "file", name: parts[1], size: parts[2] });
  }
  return entries;
}

// ------------------------------------------------------------------- /file
async function fileAction(fs, name, action) {
  const resp = await httpRequest({
    url: state.baseUrl + "/file",
    method: "GET",
    headers: authHeaders(),
    params: { fs, name, action }
  });
  return resp.data;
}

// ----------------------------------------------------------------- upload
// Verified quirk: upload target (fs+folder) is set as a side effect of the
// most recent /listfiles call, so we replay one immediately before uploading.
async function uploadFile(fs, folder, filename, base64Data, contentType) {
  await httpRequest({ url: state.baseUrl + "/listfiles", method: "GET", headers: authHeaders(), params: { fs, folder } });
  const resp = await httpRequest({
    url: state.baseUrl + "/upload",
    method: "POST",
    headers: authHeaders(),
    dataType: "formData",
    data: [
      { type: "base64File", key: "file", value: base64Data, fileName: filename, contentType: contentType || "application/octet-stream" }
    ]
  });
  return resp;
}

async function reboot() {
  return httpRequest({ url: state.baseUrl + "/reboot", method: "GET", headers: authHeaders() });
}

// ============================================================ UI wiring

function showApp() {
  $("connectScreen").classList.add("hidden");
  $("app").classList.remove("hidden");
  setStatus(true);
  refreshDashboard();
}

function setStatus(online) {
  $("statusPill").classList.toggle("offline", !online);
  $("statusText").textContent = online ? state.baseUrl.replace("http://", "") : "offline";
}

function logToConsole(text, cls) {
  const el = $("consoleLog");
  const line = document.createElement("div");
  if (cls) line.className = cls;
  line.textContent = text;
  el.appendChild(line);
  el.scrollTop = el.scrollHeight;
}

async function refreshDashboard() {
  try {
    const info = await getSystemInfo();
    $("fwVersion").textContent = info.BRUCE_VERSION || "—";
    $("statVersion").textContent = info.BRUCE_VERSION || "—";
    $("statSD").textContent = info.SD ? `${info.SD.free} free / ${info.SD.total}` : "—";
    $("statFS").textContent = info.LittleFS ? `${info.LittleFS.free} free / ${info.LittleFS.total}` : "—";
    setStatus(true);
  } catch (e) {
    setStatus(false);
  }
}

function renderFileList(entries) {
  const el = $("fileList");
  el.innerHTML = "";
  if (!entries.length) {
    el.innerHTML = '<p class="hint">Empty folder.</p>';
    return;
  }
  entries.forEach((entry) => {
    const row = document.createElement("div");
    row.className = "file-row";
    const isRunnable = /\.(ir|sub|txt|js)$/i.test(entry.name);
    row.innerHTML = `
      <span class="file-icon">${entry.type === "folder" ? "▤" : "▪"}</span>
      <span class="file-name">${entry.name}</span>
      <span class="file-size">${entry.size || ""}</span>
      ${entry.type === "file" ? `
      <div class="file-actions">
        <button data-act="download" data-name="${entry.name}">Download</button>
        <button data-act="delete" data-name="${entry.name}">Delete</button>
        ${isRunnable ? `<button data-act="run" data-name="${entry.name}">Run</button>` : ""}
      </div>` : ""}
    `;
    el.appendChild(row);
  });

  el.querySelectorAll("button[data-act]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const name = btn.dataset.name;
      const fullPath = (state.folder === "/" ? "" : state.folder) + "/" + name;
      try {
        if (btn.dataset.act === "delete") {
          await fileAction(state.fs, fullPath, "delete");
          openFolder(state.fs, state.folder);
        } else if (btn.dataset.act === "download") {
          const content = await fileAction(state.fs, fullPath, "edit");
          alert(`${name}:\n\n` + (typeof content === "string" ? content.slice(0, 500) : "(binary)"));
        } else if (btn.dataset.act === "run") {
          let cmnd;
          if (/\.ir$/i.test(name)) cmnd = "ir tx_from_file " + fullPath;
          else if (/\.sub$/i.test(name)) cmnd = "subghz tx_from_file " + fullPath;
          else if (/\.txt$/i.test(name)) cmnd = "badusb tx_from_file " + fullPath;
          else { alert("For .js scripts, open Files on the device itself (Scripts menu) — remote run syntax isn't published."); return; }
          const result = await sendCommand(cmnd);
          alert("Sent: " + cmnd + "\n" + result);
        }
      } catch (e) {
        alert("Failed: " + e.message);
      }
    });
  });
}

async function openFolder(fs, folder) {
  state.fs = fs;
  state.folder = folder;
  $("fileList").innerHTML = '<p class="hint">Loading…</p>';
  try {
    const entries = await listFiles(fs, folder);
    renderFileList(entries);
  } catch (e) {
    $("fileList").innerHTML = `<p class="hint">Failed to list files: ${e.message}</p>`;
  }
}

function switchPanel(name, title) {
  document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
  document.querySelectorAll(".bottomnav .nav-item").forEach((b) => b.classList.remove("active"));
  $("panel-" + name).classList.add("active");
  document.querySelector(`.bottomnav .nav-item[data-panel="${name}"]`).classList.add("active");
  $("topTitle").textContent = title;
}

// ---- wire up events ----
document.addEventListener("DOMContentLoaded", () => {
  $("connectForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    $("connectError").textContent = "";
    try {
      await connect($("hostInput").value.trim(), $("portInput").value.trim(), $("userInput").value.trim(), $("passInput").value);
      showApp();
    } catch (err) {
      $("connectError").textContent = err.message;
    }
  });

  document.querySelectorAll(".bottomnav .nav-item").forEach((btn) => {
    btn.addEventListener("click", () => switchPanel(btn.dataset.panel, btn.dataset.title));
  });

  $("refreshDashBtn").addEventListener("click", refreshDashboard);
  $("rebootBtn").addEventListener("click", async () => {
    if (!confirm("Reboot the Cardputer now?")) return;
    await reboot();
    logToConsole("Reboot sent.");
  });

  document.querySelectorAll(".dpad-btn, [data-nav]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try { await sendNav(btn.dataset.nav); } catch (e) { alert(e.message); }
    });
  });

  $("consoleForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const cmnd = $("consoleInput").value.trim();
    if (!cmnd) return;
    logToConsole("> " + cmnd, "line-cmd");
    $("consoleInput").value = "";
    try {
      const result = await sendCommand(cmnd);
      logToConsole(result);
    } catch (err) {
      logToConsole(err.message, "line-err");
    }
  });

  $("listBtn").addEventListener("click", () => openFolder($("fsSelect").value, $("folderInput").value.trim() || "/"));

  $("uploadInput").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result.split(",")[1];
      try {
        await uploadFile($("fsSelect").value, $("folderInput").value.trim() || "/", file.name, base64, file.type);
        alert("Uploaded " + file.name);
        openFolder($("fsSelect").value, $("folderInput").value.trim() || "/");
      } catch (err) {
        alert("Upload failed: " + err.message);
      }
    };
    reader.readAsDataURL(file);
  });

  document.querySelectorAll(".action-card[data-cmd]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        const result = await sendCommand(btn.dataset.cmd);
        alert(result);
      } catch (e) { alert(e.message); }
    });
  });

  $("ledActionBtn").addEventListener("click", async () => {
    const hex = $("ledColorInput").value;
    const r = parseInt(hex.slice(1, 3), 16), g = parseInt(hex.slice(3, 5), 16), b = parseInt(hex.slice(5, 7), 16);
    try {
      const result = await sendCommand(`led ${r} ${g} ${b}`);
      alert(result);
    } catch (e) { alert(e.message); }
  });
});
