package computer.bruce.remote;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
