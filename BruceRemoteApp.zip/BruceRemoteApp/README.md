# Bruce Remote — Android app

A native Android app that controls a Bruce-flashed M5Stack Cardputer ADV directly
over its own WebUI API — dashboard, remote D-pad, command console, file manager,
and one-tap actions.

## Read this first: why there's no .apk file attached

I built and statically verified this entire project, but **I cannot compile the
final `.apk` binary myself** — my sandbox's network policy blocks every server
an Android build needs (`dl.google.com`, `maven.google.com`,
`services.gradle.org` all returned `403`, confirmed by actually running the
build and hitting those errors). No local Gradle or Android SDK exists in the
sandbox either. I'm not going to hand you a fake or empty file pretending
otherwise — instead, everything below is real, checked source that **will**
compile correctly the moment it reaches a machine (or CI runner) with normal
internet access.

## What I actually verified before writing any code

Every API call this app makes was checked against the **real Bruce firmware
source** (`src/core/wifi/webInterface.cpp`, `BruceDevices/firmware`), not
guessed and not taken from a third-party reimplementation:

- `POST /login` (form: `username`, `password`) → `Set-Cookie: BRUCESESSION=<token>`
- Default WebUI login: `admin` / `bruce` (from the firmware's own default config)
- `POST /cm` (form: `cmnd`) — runs any serial command; the firmware's own source
  comment calls it a "Tasmota compatible API". Special `nav sel/esc/up/down/next/prev`
  sub-commands drive the physical menu remotely — that's what the Remote tab uses.
- `GET /systeminfo` → JSON with firmware version + SD/LittleFS usage
- `GET /listfiles?fs=&folder=` → text lines `pa:/Fo:/Fi:` (parsed exactly per the
  firmware's own `listFiles()` function) — **and** this call sets the device's
  internal upload target as a side effect, which the upload flow correctly replays
- `GET /file?fs=&name=&action=edit|delete|download|create|createfile`
- `POST /edit`, `POST /rename`, `POST /upload` (multipart), `GET /reboot`, `GET /wifi`
- Corrected along the way: it's **`badusb tx_from_file <path>`**, not
  `run_from_file` (a mistake I'd made in an earlier document in this project —
  the wiki's own Others page confirms `tx_from_file`).

The native networking layer uses Capacitor's built-in `CapacitorHttp` bridge
(verified from the actual `@capacitor/core` type definitions and the
`@capacitor/android` Java source in `node_modules` — including the exact
multipart/`formData` payload shape required for uploads). This talks to the
Cardputer over native HTTP, not a WebView `fetch()`, so it isn't subject to
browser CORS or mixed-content blocking the way a plain mobile browser would be.

## What I verified by actually running it in the sandbox

- `npm install` — succeeds (npm registry isn't blocked)
- `npx cap add android` / `npx cap sync android` — succeed, generate a real,
  current native project (compileSdk 36, minSdk 24, standard Capacitor 7 layout)
- Every XML file (`AndroidManifest.xml`, `network_security_config.xml`,
  `strings.xml`) — well-formed, checked with `xml.dom.minidom`
- `app.js` — valid JS syntax, checked with `node --check`
- `capacitor.config.json` — valid JSON
- The GitHub Actions workflow YAML — valid, checked with `PyYAML`
- Manually confirmed the manifest carries `android:usesCleartextTraffic="true"`
  and a `network_security_config.xml` permitting cleartext (Bruce serves plain
  HTTP; this is the standard, documented Android mechanism for that, applied
  directly after I found the CLI's automatic patch step didn't fire in this
  sandbox's Capacitor version)
- **Not verified (needs real Android tooling):** the actual compiled bytecode,
  and on-device behavior. That's the one step you'll complete below.

## Get the real .apk — GitHub Actions (fastest, ~2 minutes, no install)

1. Create a new **public or private** GitHub repo and push this whole folder to it.
2. GitHub Actions will run automatically (or open the **Actions** tab → *Build
   Bruce Remote APK* → **Run workflow**).
3. When the run finishes (green check), open it and download the
   **bruce-remote-debug-apk** artifact — that's your `.apk`.
4. Transfer it to your phone (email, cloud drive, `adb push`) and tap it to
   install. Android will ask you to allow installs from that source once.

This works because GitHub's runners aren't network-restricted the way my
sandbox is — the workflow (`.github/workflows/build-apk.yml`) runs the exact
same `npm install && npx cap sync android && ./gradlew assembleDebug` I
already validated as far as I could here.

## Alternative — build locally

If you have a normal computer with internet access:

```bash
npm install
npx cap sync android
cd android
./gradlew assembleDebug      # macOS/Linux
gradlew.bat assembleDebug    # Windows
```
The APK lands at `android/app/build/outputs/apk/debug/app-debug.apk`. Or open
the `android/` folder directly in Android Studio and hit Run/Build — it'll
fetch everything it needs automatically.

## Using the app

1. Open **Bruce Remote**, enter your Cardputer's IP (or `bruce.local`),
   the WebUI username/password (`admin`/`bruce` by default), tap **Connect**.
2. Your phone must actually be able to reach the device — same WiFi/AP, or a
   VPN/Tailscale link into its network for true off-LAN control.
3. **Dashboard** — firmware version, SD/LittleFS usage, reboot.
4. **Remote** — a D-pad that drives the on-device menu as if you were holding it.
5. **Console** — send any serial command; a verified command reference is
   built in (tap to expand).
6. **Files** — browse SD/LittleFS, upload a script/`.ir`/`.sub`/badusb `.txt`,
   download or delete, and one-tap "Run" on `.ir`/`.sub`/`.txt` files (uses the
   corrected `tx_from_file` commands). `.js` scripts upload fine but must be
   run from the device's own Scripts menu — a remote "run this specific script"
   serial syntax isn't published, so nothing here guesses at one.
7. **Actions** — one-tap versions of common commands (info, free, I²C scan,
   speak, LED colour, jump to the IR/RF/Files app on-device).

## The one rule

Anything that **transmits** — IR/Sub-GHz `tx`, `badusb tx_from_file`, WiFi/BLE
attacks reached via `loader open` — should only ever target hardware and
networks you own or are explicitly authorized to test.

## True remote (off your LAN) access

Since the app just needs network reach to the device, you can extend this
past your home WiFi using infrastructure like what you may already run:
a Tailscale subnet router advertising the Cardputer's subnet, or a reverse
tunnel — the same pattern as exposing any other home-lab service. The app
itself doesn't care how the IP became reachable.
